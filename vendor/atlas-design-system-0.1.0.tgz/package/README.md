# @atlas/design-system

Motion Applied's shared design system — dark, sharp-edged, flat, orange-accented. Extracted from
[ATLAS Web Viewer](../../README.md) so the same look and the same set of building blocks can be
reused by other Motion Applied tools (e.g. a log-monitoring dashboard), while ATLAS.web itself
consumes this package rather than owning its own duplicate copy.

React 19 + TypeScript + Tailwind v4 (CSS-first config, no `tailwind.config.js`) + shadcn/ui
("new-york" style, `baseColor: neutral`). Dark-only — there is no light theme.

## What's in here

- **Tokens** (`src/styles/tokens.css`, `src/tokens/palette.ts`, `src/tokens/fonts.ts`) — the shadcn
  colour/radius/font variables plus a categorical chart-series palette (`--chart-1..5`) and semantic
  severity colours (`--ok`/`--warn`/`--error`). `palette.ts`/`fonts.ts` mirror the same values in
  plain TS for any JS-land consumer that can't read CSS custom properties (e.g. a canvas/WebGL
  renderer) — keep both in sync by hand if you change a colour.
- **Primitives** (`src/components/ui/*`) — `Button`, `Badge`, `Dialog`, `DropdownMenu`, `Input`,
  `Label`, `ScrollArea`, `Select`, `Separator`, `Toaster` (sonner), `Tabs`, `Tooltip`, `Table`.
- **Composites** (`src/components/composite/*`) — `StatusBadge` (ok/warn/error/info/neutral pill),
  `EmptyState`, `DataTable` (sortable, no tanstack dependency), `AppShell` (toolbar/side-panel/main/
  status-bar layout frame), `Brand` (wordmark + icon + sub-label slot).

Everything is exported from the package root: `import { Button, StatusBadge, AppShell } from '@atlas/design-system'`.

## Consuming this package

### From inside this monorepo (ATLAS Web Viewer)

Already wired up — the app resolves `@atlas/design-system` straight from this package's `src/`
via a path alias (see the root `tsconfig.app.json`/`vite.config.ts`), so there's no build step in
the dev loop. `src/components/ui/*.tsx` in the app are thin re-export shims over this package.

### From another repo

This package is not (yet) published to a registry. Until it is, consume it one of these ways:

1. **Build once, copy the tarball**: from this directory, `npm run build`, then `npm pack` to
   produce `atlas-design-system-<version>.tgz`, and `npm install /path/to/atlas-design-system-*.tgz`
   in the consuming project.
2. **Git dependency on a subdirectory**: most package managers support pinning a dependency to a
   subdirectory of a git repo at a specific ref (syntax varies by tool/registry — check what your
   consuming project's package manager supports for this ATLAS.web repo's remote).

A future step (not done yet) would be publishing to a private npm registry so consumers can just
`npm install @atlas/design-system`.

### Required setup in the consuming app

1. Install peer dependencies: `react`, `react-dom`, `tailwindcss` (v4).
2. Import the stylesheet once, at your app's entry point: `import '@atlas/design-system/styles/index.css'`.
3. Wire Tailwind v4 into your own build (e.g. the `@tailwindcss/vite` plugin) — this package ships
   raw, unprocessed CSS; your app's own Tailwind build is what compiles it.
4. **Tailwind v4 content scanning**: Tailwind v4 auto-detects content but excludes `node_modules` by
   default. Since this package's components live under `node_modules/@atlas/design-system/` once
   installed externally, add an explicit source directive so Tailwind actually generates the
   utility classes those components use:
   ```css
   @source "../node_modules/@atlas/design-system/dist";
   ```
   (path relative to wherever you put this in your own CSS entry file).
5. Use components: `import { Button, StatusBadge, DataTable, AppShell, Brand } from '@atlas/design-system'`.

### Example: a log-monitoring shell

```tsx
import { AppShell, Brand, DataTable, StatusBadge } from '@atlas/design-system';

function LogViewer() {
  return (
    <AppShell
      toolbar={<Brand wordmark="LOGWATCH" subLabel="Live" />}
      sidePanel={<FilterPanel />}
    >
      <DataTable
        columns={[
          { key: 'time', header: 'Time', sortable: true },
          {
            key: 'level',
            header: 'Level',
            render: (row) => (
              <StatusBadge status={row.level === 'error' ? 'error' : row.level === 'warn' ? 'warn' : 'info'}>
                {row.level}
              </StatusBadge>
            ),
          },
          { key: 'message', header: 'Message' },
        ]}
        rows={logRows}
        rowKey={(row) => row.id}
      />
    </AppShell>
  );
}
```

## Developing this package

- `npm run build` (from this directory, or `npm run build --workspace=packages/design-system` from
  the repo root) — type-checks via `tsc -b` then produces `dist/` (ESM + `.d.ts`) via Vite library
  mode, for external distribution.
- There's no separate lint/test config here — this package is covered by ATLAS.web's root `eslint`
  and `vitest` config (co-located `*.test.tsx` files under `src/` run under the root `npm run test`).
- Adding a new shadcn primitive: run the shadcn CLI from **inside this directory** (it has its own
  `components.json`) — running it from the ATLAS.web repo root would generate files into ATLAS.web's
  own `src/components/ui` instead. Rewrite the generated file's `@/lib/utils` import to the relative
  `../../lib/utils` before committing — this package intentionally has no `@` path alias, so it
  never collides with whatever `@` alias a consuming app defines for itself.
- Keep `src/styles/tokens.css` and `src/tokens/palette.ts`/`fonts.ts` in sync by hand when changing a
  colour — they're independent sources of truth for the same palette (CSS custom properties vs. a
  plain-JS mirror for non-CSS consumers).

## Explicitly out of scope (for now)

- No Storybook or docs site — this README is the documentation.
- No light theme / `next-themes` wiring — dark-only, matching ATLAS Web Viewer today.
- No registry publish yet — see "From another repo" above.
